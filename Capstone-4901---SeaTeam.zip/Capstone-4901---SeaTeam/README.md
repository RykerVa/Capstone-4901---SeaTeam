# Capstone-4901---SeaTeam

Go mod file needed to run projects on your machine.
  - In a new directory run 'go mod init NewGoProject' replacing NewGoProject with your project name.
  - From here you can add your Go files to this module.
